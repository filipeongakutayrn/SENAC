package br.senac.rn.agenda.controller;

public class ContatoController {
}
