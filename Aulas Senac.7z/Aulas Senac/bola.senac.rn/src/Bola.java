public class Bola {
    String Cor = ("Verde");
    Double Medida = 10.0;
    String Material = ("Couro");

    public void setCor(String cor) {
        Cor = cor;
    }

    public void setMaterial(String material) {
        Material = material;
    }

    public void setMedida(Double medida) {
        Medida = medida;
    }

}
