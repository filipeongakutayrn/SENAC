package model;

public class PessoaFilipe {
    public static void main(String[] args) {
        String nome = "Filipe Monteiro";
        int idade = 32;
        Double altura = 1.65;
        System.out.println(nome + "\n");
        System.out.println("Sua altura é: " + altura + "\n");
        System.out.println("Sua idade é: " + idade + " anos");

    }

}
